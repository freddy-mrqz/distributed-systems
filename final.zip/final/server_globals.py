#! python
connections = []

ports = {}
